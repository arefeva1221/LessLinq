﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Less.linq
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        DataBaseContext dataContext = new DataBaseContext();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string[] nameRandom =
            {
            "Натали",
            "Сергей",
            "Иван",
            "Ольга",
            "Анастасия"
            };

           // nameRandom.Min();

            string[] surnameRandom =
            {
            "Иванов",
            "Черемушкин",
            "Трухин",
            "Николаева",
            "Анурова",
            "Ильин",
            "Васильева",
            "Рейн"
            };



            List<People> people = new List<People>();
            Random rand = new Random();
            for (int i = 0; i <= 5; i++)
            {
                People p = new People()
                {
                    FirstName = nameRandom[rand.Next(nameRandom.Length)],
                    Surname = surnameRandom[rand.Next(surnameRandom.Length)],
                    Birthday = new DateTime(rand.Next(1990,2005),rand.Next(1,12),rand.Next(1,31)),
                    Rise = rand.NextDouble() * rand.Next(100,190),
                    Weight = rand.NextDouble() * rand.Next(50,100)
                };
                people.Add(p);
            }
            lvGeneratePeople.ItemsSource = people;

            dataContext.peoples.AddRange(people);
            dataContext.SaveChanges();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.OrderBy(Weight => Weight.Weight).ToList();
            tbCountPeople.Text = $"Количество людей в БД:{dataContext.peoples.Count().ToString()}";
           
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.OrderByDescending(Weight => Weight.Weight).ToList();
            tbCountPeople.Text = $"Количество людей в БД:{dataContext.peoples.Count().ToString()}";
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.OrderBy(Rise => Rise.Rise).ToList();
            tbCountPeople.Text = $"Количество людей в БД:{dataContext.peoples.Count().ToString()}";
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.OrderByDescending(Rise => Rise.Rise).ToList();
            tbCountPeople.Text = $"Количество людей в БД:{dataContext.peoples.Count().ToString()}";
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.OrderBy(Birthday => Birthday.Birthday).ToList();
            tbCountPeople.Text = $"Количество людей в БД:{dataContext.peoples.Count().ToString()}";
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.OrderByDescending(Birthday => Birthday.Birthday).ToList();
            tbCountPeople.Text = $"Количество людей в БД:{dataContext.peoples.Count().ToString()}";
          
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            string nameW = $"Среднее значение по весу - {dataContext.peoples.Average(Weight => Weight.Weight)}";
           // MessageBox.Show(nameW);

           // lvSorting.ItemsSource = dataContext.peoples.Average(Weight => Weight.Weight).ToString();
            tbCountPeople2.Text = nameW.ToString();
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            var name = (from pp in dataContext.peoples
                             where pp.Weight == dataContext.peoples.Max(p => p.Weight)
                             select pp.FirstName).First();
            string nameW = $"Имя - {name}, вес = {dataContext.peoples.Max(p => p.Weight)}";
            MessageBox.Show(nameW);

        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            double sumW = dataContext.peoples.Sum(p => p.Weight);
            MessageBox.Show(sumW.ToString());
        }

        private void lvSorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void lvGeneratePeople_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
