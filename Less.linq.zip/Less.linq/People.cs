﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Less.linq
{
    public class People
    {
       public int Id { get; set; }

        public string FirstName { get; set; } //Имя
        public string Surname { get; set; } //Фамилия
        public DateTime Birthday { get; set; } //Дата рождения

        public double Rise { get; set; } //Рост
        public double Weight { get; set; } //Вес





    }
}
